#include<stdio.h>

int main(){
   printf("My answer is comment in source code!\n");

   // if both of 2 arrays are short all the changes do not have more affect
   // we considering if 2 arrays have at least 10000 element!
   // after an element is checked, we remove it form arrays


   return 0;
}